package db;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
public class Database {
	String url = "";
	String user = "";
	String pass = "";
	
	Connection con = null;
	
	public Database()throws ClassNotFoundException {
		
		
		Statement st = null;
		//1.드라이버를 로딩
		
			Class.forName("oracle.jdbc.driver.OracleDriver");
		
		//2.연결 객체 얻어오기
			String url = "jdbc:oracle:thin:@192.168.0.156:1521:orcl";
			String user = "been";
			String pass = "love1998";
			try {
				con = DriverManager.getConnection(url, user, pass);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			System.out.println("연결성공");
		
	}
	


}
