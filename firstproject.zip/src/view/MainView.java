package view;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Frame;
import java.awt.GridLayout;
import java.awt.Panel;
import java.util.ArrayList;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.table.AbstractTableModel;


public class MainView {
	Frame f_main; //main frame
	
	JMenuBar mb_main; //관리자  menu
	
	JMenuItem mi_admin;//관리자 메뉴
	JMenuItem mi_emp;//직원관리
	JMenuItem mi_menu;//메뉴관리
	JMenuItem mi_chat;//주방과의 채팅 프로그램
	JMenuItem mi_graph;//매출관리 
	
	JLabel l_logo; //main logo
	JLabel l_empname; //login한 직원표시
	JLabel l_total;//총구매금액 표시
	
	JButton b_admin;//관리자메뉴
	JButton b_in;//출근
	JButton b_out;//로그아웃
	JButton b_plus;//주문추가
	JButton b_minus;//주문삭제
	JButton b_recipt;//영수증 출력
	JButton b_cost;//결제
	
	JTextArea ta_chat;
	
	JTable tbl_menu; //menu table
	JTable tbl_cost;// 구매 목록 table
	BurgerTableModelMenu tbModelMenu;
	BurgerTableModelCost tbModelCost;
	public void SetUI(){
		f_main = new Frame("Burger King pos");
	
		JMenuBar mb_main = new JMenuBar();
		
		b_admin = new JButton("관리자 메뉴");
	
		
		l_logo = new JLabel(new ImageIcon("src/img/logo.png")); 
		l_empname = new JLabel("로그인한 직원"); //login한 직원표시
		l_total = new JLabel("000000");//총구매금액 표시
		
		b_in = new JButton("출근");
		b_out = new JButton("퇴근");//로그아웃
		b_plus = new JButton("+");//주문추가
		b_minus = new JButton("-");//주문삭제
		b_recipt = new JButton("이전 영수증");//영수증 출력
		b_cost= new JButton("결제");//결제
		
		ta_chat = new JTextArea(1,45);
		tbModelMenu = new BurgerTableModelMenu();
		tbModelCost = new BurgerTableModelCost();
		JTable tbl_menu = new JTable(tbModelMenu); //menu table
		JTable tbl_cost = new JTable(tbModelCost);// 구매 목록 table
	}
	
	public void Display() {
		f_main.setBackground(Color.WHITE);
		
		f_main.setLayout(new BorderLayout());
		
		Panel p1 = new Panel();
		p1.setLayout(new BorderLayout());
		
		p1.add(l_logo,BorderLayout.CENTER);
		p1.add(b_admin,BorderLayout.EAST);
		f_main.add(p1,BorderLayout.NORTH);
		
		Panel p2 = new Panel();
		p2.setLayout(new GridLayout(1,6));
		p2.add(new JLabel("사람그림"));
		p2.add(new JLabel("카운터 담당 : "));
		p2.add(l_empname);
		p2.add(new JLabel(""));
		p2.add(b_in);
		p2.add(b_out);
		
		Panel p3 = new Panel();
		p3.setLayout(new BorderLayout());
		p3.add(p2, BorderLayout.NORTH);
		p3.add(new JScrollPane(tbl_menu),BorderLayout.CENTER);
		
		f_main.add(p3, BorderLayout.WEST);
		
		Panel p4 = new Panel();
		p4.setLayout(new GridLayout(5, 3));
		p4.add(new JLabel(""));
		p4.add(new JLabel(""));
		p4.add(new JLabel(""));
		p4.add(new JLabel(""));
		p4.add(b_plus);
		p4.add(new JLabel(""));
		p4.add(new JLabel(""));
		p4.add(new JLabel(""));
		p4.add(new JLabel(""));
		p4.add(new JLabel(""));
		p4.add(b_minus);
		p4.add(new JLabel(""));
		p4.add(new JLabel(""));
		p4.add(new JLabel(""));
		p4.add(new JLabel(""));
		
		f_main.add(p4, BorderLayout.CENTER);
		
		Panel p5 = new Panel();
		p5.setLayout(new BorderLayout());
		
		Panel p6 = new Panel();
		p6.setLayout(new GridLayout(2,1));
		
		Panel p7 = new Panel();
		p7.setLayout(new GridLayout(1,2));
		p7.add(new JLabel(""));
		
		Panel p8 = new Panel();
		p8.setLayout(new GridLayout(1,2));
		p8.add(new JLabel("총 금액 : "));
		p8.add(l_total);
		
		p7.add(p8);
		
		p6.add(p7);
		p6.add(ta_chat);
		
		p5.add(new JScrollPane(tbl_cost), BorderLayout.CENTER);
		p5.add(p6,BorderLayout.SOUTH);
		
		
		
		f_main.add(p5, BorderLayout.EAST);
		
		Panel p9 = new Panel();
		p9.setLayout(new GridLayout(1,3));
		p9.add(new JLabel(""));
		p9.add(new JLabel(""));
		
		Panel p10 = new Panel();
		p10.setLayout(new GridLayout(1,2));
		p10.add(b_recipt);
		p10.add(b_cost);
		
		p9.add(p10);
		
		f_main.add(p9, BorderLayout.SOUTH);
		
		f_main.setSize(1000, 500);
		f_main.setVisible(true);
		
	}
	
	class BurgerTableModelMenu extends AbstractTableModel { 
		  
		ArrayList data = new ArrayList();
		String [] columnNames = {"메뉴명","가격","카테고리"};

		//=============================================================
		// 1. 기본적인 TabelModel  만들기
		// 아래 세 함수는 TabelModel 인터페이스의 추상함수인데
		// AbstractTabelModel에서 구현되지 않았기에...
		// 반드시 사용자 구현 필수!!!!

		    public int getColumnCount() { 
		        return columnNames.length; 
		    } 
		     
		    public int getRowCount() { 
		        return data.size(); 
		    } 

		    public Object getValueAt(int row, int col) { 
				ArrayList temp = (ArrayList)data.get( row );
		        return temp.get( col ); 
		    }
		    
		    public String getColumnName(int col){
		    	return columnNames[col];
		    }
	}
	
	class BurgerTableModelCost extends AbstractTableModel { 
		  
		ArrayList data = new ArrayList();
		String [] columnNames = {"메뉴명","가격","개수"};

		//=============================================================
		// 1. 기본적인 TabelModel  만들기
		// 아래 세 함수는 TabelModel 인터페이스의 추상함수인데
		// AbstractTabelModel에서 구현되지 않았기에...
		// 반드시 사용자 구현 필수!!!!

		    public int getColumnCount() { 
		        return columnNames.length; 
		    } 
		     
		    public int getRowCount() { 
		        return data.size(); 
		    } 

		    public Object getValueAt(int row, int col) { 
				ArrayList temp = (ArrayList)data.get( row );
		        return temp.get( col ); 
		    }
		    
		    public String getColumnName(int col){
		    	return columnNames[col];
		    }
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	public static void main(String [] args) {
		MainView mv = new MainView();
		mv.SetUI();
		mv.Display();
	}
}




