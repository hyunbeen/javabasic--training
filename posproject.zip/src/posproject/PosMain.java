package posproject;

public class PosMain {

	public static void main(String[] args) {
			PosLayout pos = new PosLayout();
			pos.setUI();
			pos.evtproc();

	}

}
